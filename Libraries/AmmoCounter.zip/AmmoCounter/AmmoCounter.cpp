/*
|| @file AmmoCounter.cpp
|| @version 1.0
|| @author Nathaniel Deal
|| @contact info@ammocounter.com
||
|| @description
|| Provides a interface for AmmoCounter PCB board, LEDs and shift registers.
|| 
|| @changelog
|| 1.0 2016-10-3 - Nathaniel Deal : Class implemented
||  
*/

#include "AmmoCounter.h" //include the declaration for this class

//Constructor
AmmoCounter::AmmoCounter(){

	// Setup register pins
	pinMode(_SER_Pin, OUTPUT);
	pinMode(_RCLK_Pin, OUTPUT);
	pinMode(_SRCLK_Pin, OUTPUT);
	
	// Reset all register pins
	_clearRegisters();
	_writeRegisters();
}

//Change Number
void AmmoCounter::displayNumber(int displayCount){

	if( (displayCount < 100) && (displayCount > 9) ) {

		_firstDigit = displayCount / 10; // Find the first digit
		_secondDigit = displayCount % 10; 

		_setNumber(_firstDigit,_secondDigit); //Display the digits
		displayCount--;

		_writeRegisters();  //Send data to the 75HC595
	}

	else if( (displayCount < 10) && (displayCount > 0) ) {

		_firstDigit = 0; // Set the first digit to 0
		_secondDigit = displayCount;

		_setNumber(_firstDigit,_secondDigit); //Display the section
		displayCount--;

		_writeRegisters();
	}

	else if( displayCount == 0) {

		_firstDigit = 0; // Set the first digit to 0
		_secondDigit = 0; // Set the second digit to 0

		_setNumber(_firstDigit,_secondDigit); //Display the section
		_writeRegisters(); 

		_blinkDisplay(3); // Blink display
	}
}

void AmmoCounter::_setNumber(int digit1, int digit2) {

  for (int digit = numOfRegisterPins ; digit > 0 ; digit--) {
    
    //Turn on the right segments for this digit
    _firstNumber(digit1);
    _secondNumber(digit2);
    
  }

}

void AmmoCounter::_firstNumber(int numberToDisplay) {
  
  switch (numberToDisplay){
    
  // Display number 0
  case 0:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, LOW);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, HIGH);
    break;
  
  // Display number 1
  case 1:
    _setRegisterPin(0, HIGH);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, HIGH);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, HIGH);
    _setRegisterPin(6, HIGH);
    break; 
  
  // Display number 2
  case 2:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, HIGH);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, LOW);
    _setRegisterPin(5, HIGH);
    _setRegisterPin(6, LOW);
    break;
  
  // Display number 3
  case 3:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, HIGH);
    _setRegisterPin(6, LOW);
    break;   

  // Display number 4
  case 4:
    _setRegisterPin(0, HIGH);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, HIGH);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, LOW);
    break;

  // Display number 5
  case 5:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, HIGH);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, LOW);
    break;
  
  // Display number 6
  case 6:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, HIGH);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, LOW);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, LOW);
    break;

  // Display number 7
  case 7:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, HIGH);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, HIGH);
    _setRegisterPin(6, HIGH);
    break;

  // Display number 8
  case 8:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, LOW);
    _setRegisterPin(4, LOW);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, LOW);
    break;
  
  // Display number 9
  case 9:
    _setRegisterPin(0, LOW);
    _setRegisterPin(1, LOW);
    _setRegisterPin(2, LOW);
    _setRegisterPin(3, HIGH);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, LOW);
    _setRegisterPin(6, LOW);
    break;
    
  // Turn off display
  case 10:
    _setRegisterPin(0, HIGH);
    _setRegisterPin(1, HIGH);
    _setRegisterPin(2, HIGH);
    _setRegisterPin(3, HIGH);
    _setRegisterPin(4, HIGH);
    _setRegisterPin(5, HIGH);
    _setRegisterPin(6, HIGH);
    break;
  
  }
}

void AmmoCounter::_secondNumber(int numberToDisplay) {
  
  switch (numberToDisplay){
    
  // Display number 0
  case 0:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, LOW);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, HIGH);
    break;
  
  // Display number 1
  case 1:
    _setRegisterPin(8, HIGH);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, HIGH);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, HIGH);
    _setRegisterPin(14, HIGH);
    break; 
  
  // Display number 2
  case 2:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, HIGH);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, LOW);
    _setRegisterPin(13, HIGH);
    _setRegisterPin(14, LOW);
    break;
  
  // Display number 3
  case 3:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, HIGH);
    _setRegisterPin(14, LOW);
    break;   

  // Display number 4
  case 4:
    _setRegisterPin(8, HIGH);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, HIGH);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, LOW);
    break;

  // Display number 5
  case 5:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, HIGH);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, LOW);
    break;
  
  // Display number 6
  case 6:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, HIGH);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, LOW);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, LOW);
    break;

  // Display number 7
  case 7:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, HIGH);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, HIGH);
    _setRegisterPin(14, HIGH);
    break;

  // Display number 8
  case 8:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, LOW);
    _setRegisterPin(12, LOW);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, LOW);
    break;
  
  // Display number 9
  case 9:
    _setRegisterPin(8, LOW);
    _setRegisterPin(9, LOW);
    _setRegisterPin(10, LOW);
    _setRegisterPin(11, HIGH);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, LOW);
    _setRegisterPin(14, LOW);
    break;
    
  // Turn off display
  case 10:
    _setRegisterPin(8, HIGH);
    _setRegisterPin(9, HIGH);
    _setRegisterPin(10, HIGH);
    _setRegisterPin(11, HIGH);
    _setRegisterPin(12, HIGH);
    _setRegisterPin(13, HIGH);
    _setRegisterPin(14, HIGH);
    break;
  
  }
}  

//Set an individual pin HIGH or LOW
void AmmoCounter::_setRegisterPin(int index, int value){
	_registers[index] = value;
}

//Clear Shift Registers
void AmmoCounter::_clearRegisters(){
	for(int i = numOfRegisterPins - 1; i >=  0; i--){
		_registers[i] = HIGH;
	}
}

//Write Shift Registers
void AmmoCounter::_writeRegisters(){

	//Open Registers
	digitalWrite(_RCLK_Pin, LOW);

	// Push data
	for (int i = numOfRegisterPins - 1; i >=  0; i--) {
		digitalWrite(_SRCLK_Pin, LOW);

		int val = _registers[i];

		digitalWrite(_SER_Pin, val);
		digitalWrite(_SRCLK_Pin, HIGH);
	}

	//Close Registers
	digitalWrite(_RCLK_Pin, HIGH);
}

//Turn the display off and on
void AmmoCounter::_blinkDisplay(int count){

  for (int i=0; i < count; i++){
    
    //Turn off the display
    _setNumber(10,10);
    _writeRegisters();
    delay(500);
    
    //Turn on display
    _setNumber(_firstDigit, _secondDigit); 
    _writeRegisters(); 
    delay(500);
  }  
}