/*
||
|| @file AmmoCounter.h
|| @version 1.0
|| @author Nathaniel Deal
|| @contact info@ammocounter.com
||
|| @description
|| | Provides a interface for AmmoCounter PCB board, LEDs and shift registers.
|| #
*/

#ifndef AmmoCounter_h
#define AmmoCounter_h

// For Arduino 1.0 and earlier
#if defined(ARDUINO) && ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

//Define shift registers
#define number_of_74hc595s 2
#define numOfRegisterPins number_of_74hc595s * 8

class AmmoCounter { 
	public:
		AmmoCounter();
		void displayNumber(int displayCount);
	private:
		void _clearRegisters();
		void _writeRegisters();
		void _firstNumber(int numberToDisplay);
		void _secondNumber(int numberToDisplay);
		void _setRegisterPin(int index, int value);
		void _setNumber(int digit1, int digit2);
		void _blinkDisplay(int count);

		int _firstDigit;     				// First LED Digit
		int _secondDigit;    				// Second LED Digit
		int _SER_Pin = 7;   				// Serial-In pin 14 on the 75HC595 (Blue)
		int _RCLK_Pin = 8;  				// Latch Clock pin 12 on the 75HC595 (Yellow)
		int _SRCLK_Pin = 9; 				// Clock pin 11 on the 75HC595 (Green)
		bool _registers[numOfRegisterPins]; // Array for number of registers
};

#endif

/*
|| @changelog
|| | 1.0 2016-10-3 - Nathaniel Deal : Initial Release
|| #
*/